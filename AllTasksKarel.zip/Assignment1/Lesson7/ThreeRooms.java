package Lesson7;

import stanford.karel.SuperKarel;

public class ThreeRooms extends SuperKarel{
	public void run() { 
	}

}
