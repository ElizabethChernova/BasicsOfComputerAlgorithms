package Lesson7;

import stanford.karel.SuperKarel;

public class Labirithm extends SuperKarel{
	public void run() { 
	}
}

