package Lesson9_10;

import stanford.karel.SuperKarel;

public class FindExitFromLabirithm extends SuperKarel{
	//first task: only --------- such lines
	//second task: only |  |  | such lines
	//third task: both variant of lines(but one line distance)
	//forth task: any labirithm

	
	//variants of tasks: 1)find beeper and stop there 2_collect all beepers
	public void run() { 
	
		}
		
		
	}


