package Lesson3;

import stanford.karel.SuperKarel;

public class CollectAllBeepers_intheRow_ifExist extends SuperKarel{
	public void run() { 

	}
	}