package Lesson3;

import stanford.karel.*;

public class CollectAllBeepers_iftheyExist extends SuperKarel{
	public void run() { 
		
}
	
}