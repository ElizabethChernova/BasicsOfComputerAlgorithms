package Lesson4;

import stanford.karel.*;


public class FindBeeper extends SuperKarel{
	public void run() { 
		findBeeperInRow();
		//findBeeperInWorld();
}
	private void findBeeperInRow(){}
	private void findBeeperInWorld(){}
}