package Lesson6;

public class OnlyOneBeeperInRowDecomposition {

}
