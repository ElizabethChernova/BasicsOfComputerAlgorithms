package Lesson6;

import stanford.karel.SuperKarel;

public class Midpoint  extends SuperKarel{
	public void run() { 
	}
}
