package Lesson1;


import stanford.karel.*;

public class StoneMasonKarel extends SuperKarel {

	// You fill in this part

}
