package Lesson2;
import stanford.karel.*;


public class CollectAllBeepers extends SuperKarel{
	public void run() { 
		
		
		
	}
}
