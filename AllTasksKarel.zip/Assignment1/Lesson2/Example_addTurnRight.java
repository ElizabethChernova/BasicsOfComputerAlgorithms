package Lesson2;
import stanford.karel.*;


public class Example_addTurnRight extends SuperKarel{
	public void run() { 
	
		move();
		turnLeft();
		//putBeeper();
		pickBeeper();
		turn_Right();
		  
		}
	private void turn_Right(){
		
	}
	
}
