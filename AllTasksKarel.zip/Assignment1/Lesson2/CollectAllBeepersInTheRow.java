package Lesson2;
import stanford.karel.*;
public class CollectAllBeepersInTheRow extends SuperKarel{
	public void run() { 
		while(frontIsClear()){
		pickBeeper();
		move();}
		pickBeeper();
		
	}
}
